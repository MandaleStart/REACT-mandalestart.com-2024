import { Link, useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';
import './navbar.css';

const Navbar = () => {
  const [openMenu, setOpenMenu] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => {
    setOpenMenu('');
    setMobileOpen(false);
  }, [pathname]);

  const navItems = [
    { to: '/', label: 'Inicio' },
    { to: '/projects', label: 'Proyectos' },
    { to: '/aboutme', label: 'Sobre mí' },
    { to: '/contact', label: 'Contacto' },
  ];

  const serviceLinks = [
    { to: '/services', label: 'Todos los servicios' },
    { to: '/services/web', label: 'Desarrollo web' },
    { to: '/services/hosting', label: 'Hosting web' },
    { to: '/services/email', label: 'Correo empresarial' },
    { to: '/services/domains', label: 'Dominios' },
    { to: '/services/seo', label: 'SEO' },
    { to: '/services/ddns', label: 'DDNS' },
    { to: '/services/monitoring', label: 'Infraestructura' },
    { to: '/services/impresion-3d', label: 'Diseño e impresión 3D' },
  ];

  const moreLinks = [
    { to: '/client-area', label: 'Área de clientes' },
    { to: '/admin', label: 'Administración' },
    { to: '/comments', label: 'Opiniones' },
    { to: '/cv', label: 'CV' },
  ];

  const toggleMenu = (menu) => {
    setOpenMenu((currentMenu) => (currentMenu === menu ? '' : menu));
  };

  const closeMenus = () => {
    setOpenMenu('');
    setMobileOpen(false);
  };

  return (
    <header className="topbar-wrap">
      <nav className="topbar navbar-container">
        <div className="topbar-inner">
          <Link className="brand" to="/">
            <span className="brand-mark">M</span>
            <span>
              <strong>MandaleStart</strong>
              <small>Web y soporte técnico</small>
            </span>
          </Link>

          <button
            className="navbar-toggler"
            type="button"
            aria-controls="main-navigation"
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? 'Cerrar menú de navegación' : 'Abrir menú de navegación'}
            onClick={() => setMobileOpen((isOpen) => !isOpen)}
          >
            <span className="navbar-toggler-icon" aria-hidden="true" />
          </button>

          <div className={`navbar-collapse${mobileOpen ? ' is-open' : ''}`} id="main-navigation">
            <div className="navbar-nav">
              {navItems.map(({ to, label }) => (
                <Link key={to} className="nav-link" to={to} onClick={closeMenus}>
                  {label}
                </Link>
              ))}

              <div className={`nav-dropdown${openMenu === 'services' ? ' is-open' : ''}`}>
                <button
                  type="button"
                  className="nav-link nav-dropdown-toggle"
                  aria-haspopup="true"
                  aria-expanded={openMenu === 'services'}
                  onClick={() => toggleMenu('services')}
                >
                  Servicios
                </button>
                <div className="nav-dropdown-menu">
                  {serviceLinks.map(({ to, label }) => (
                    <Link key={to} className="nav-dropdown-link" to={to} onClick={closeMenus}>
                      {label}
                    </Link>
                  ))}
                </div>
              </div>

              <div className={`nav-dropdown${openMenu === 'more' ? ' is-open' : ''}`}>
                <button
                  type="button"
                  className="nav-link nav-dropdown-toggle"
                  aria-haspopup="true"
                  aria-expanded={openMenu === 'more'}
                  onClick={() => toggleMenu('more')}
                >
                  Más
                </button>
                <div className="nav-dropdown-menu">
                  {moreLinks.map(({ to, label }) => (
                    <Link key={to} className="nav-dropdown-link" to={to} onClick={closeMenus}>
                      {label}
                    </Link>
                  ))}
                </div>
              </div>

              <Link className="nav-cta" to="/contact" onClick={closeMenus}>
                Pedir presupuesto
              </Link>
            </div>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;