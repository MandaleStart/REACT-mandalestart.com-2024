import { Link } from 'react-router-dom';
import { useContact } from '../../config/useContact';
import { SITE, mailtoUrl, telUrl } from '../../config/site';

const Footer = () => {
  const contact = useContact();

  return (
    <footer className="site-footer">
      <div className="footer-top">
        <div className="footer-brand-block">
          <div className="brand brand-footer">
            <span className="brand-mark">M</span>
            <span>
              <strong>{SITE.name}</strong>
              <small>Web y soporte técnico</small>
            </span>
          </div>
          <p>Desarrollo web, hosting y soporte técnico para personas y negocios de todo Uruguay.</p>
        </div>

        <div className="footer-links">
          <h6>Explorar</h6>
          <Link to="/">Inicio</Link>
          <Link to="/services">Servicios</Link>
          <Link to="/projects">Proyectos</Link>
          <Link to="/aboutme">Sobre mí</Link>
          <Link to="/contact">Contacto</Link>
          <Link to="/comments">Opiniones</Link>
          <Link to="/cv">CV</Link>
          <Link to="/client-area">Área de clientes</Link>
        </div>

        <div className="footer-links">
          <h6>Servicios</h6>
          <span>Desarrollo web</span>
          <span>Hosting, dominios y correo</span>
          <span>Redes y servidores</span>
          <Link to="/services/impresion-3d">Diseño e impresión 3D</Link>
        </div>

        <div className="footer-contact">
          <h6>Contacto</h6>
          <a href={mailtoUrl(contact)}>{contact.email}</a>
          {contact.phone && <a href={telUrl(contact)}>{contact.phone.display}</a>}
          <span>Atención en todo Uruguay</span>
        </div>
      </div>

      <div className="footer-bottom">
        <span>© 2026 MandaleStart</span>
        <Link to="/privacidad" className="footer-privacy">
          Información de privacidad
        </Link>
      </div>
    </footer>
  );
};

export default Footer;