const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');

export async function getPublicServices(signal) {
  const response = await fetch(`${API_BASE_URL}/api/services`, { signal });
  if (!response.ok) throw new Error('No se pudo actualizar el catálogo de servicios.');

  const services = await response.json();
  if (!Array.isArray(services)) throw new Error('El catálogo recibido no tiene un formato válido.');
  return services;
}

export async function getPublicServiceBySlug(slug, signal) {
  const response = await fetch(`${API_BASE_URL}/api/services/${encodeURIComponent(slug)}`, { signal });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error('No se pudo consultar el servicio.');

  const service = await response.json();
  if (!service || typeof service !== 'object' || Array.isArray(service)) {
    throw new Error('El servicio recibido no tiene un formato válido.');
  }
  return service;
}
