const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');

export async function submitContactMessage(message) {
  let response;
  try {
    response = await fetch(`${API_BASE_URL}/api/contact`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(message),
    });
  } catch {
    throw new Error('No se pudo conectar con el servidor. Podés contactarnos por email.');
  }

  const payload = await response.json().catch(() => null);
  if (!response.ok) {
    throw new Error(payload?.message || 'No se pudo enviar tu consulta. Podés contactarnos por email.');
  }

  return payload;
}
