import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useContact } from '../../../config/useContact';
import { whatsappUrl } from '../../../config/site';
import { submitContactMessage } from '../../../services/contactApi';
import './mail.css';

const MailBox = () => {
  const contact = useContact();
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState(null);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);

    setSubmitting(true);
    setFeedback(null);
    try {
      const result = await submitContactMessage({
        name: formData.get('name'),
        email: formData.get('email'),
        service: formData.get('service'),
        message: formData.get('message'),
        website: formData.get('website'),
      });
      form.reset();
      setFeedback({ type: 'success', message: result.message });
    } catch (error) {
      setFeedback({ type: 'error', message: error.message });
    } finally {
      setSubmitting(false);
    }
  };

  const handleWhatsApp = (event) => {
    const form = event.currentTarget.form;
    if (!form.reportValidity()) return;

    const formData = new FormData(form);
    const service = form.elements.service.selectedOptions[0]?.textContent || '';
    const message = `Nombre: ${formData.get('name')}\nEmail: ${formData.get('email')}\nServicio: ${service}\n\nMensaje:\n${formData.get('message')}`;
    const url = whatsappUrl(contact, message);
    if (url) window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <form className="contact-form" onSubmit={handleSubmit}>
      <div className="contact-form-honeypot" aria-hidden="true">
        <label htmlFor="website">Dejá este campo vacío</label>
        <input id="website" name="website" type="text" tabIndex="-1" autoComplete="off" />
      </div>
      <div className="form-row">
        <div className="field-group">
          <label htmlFor="name">Nombre</label>
          <input type="text" id="name" name="name" autoComplete="name" placeholder="Tu nombre" required />
        </div>
        <div className="field-group">
          <label htmlFor="email">Email</label>
          <input type="email" id="email" name="email" autoComplete="email" placeholder="tu@email.com" required />
        </div>
      </div>

      <div className="field-group">
        <label htmlFor="service">Servicio</label>
        <select id="service" name="service" defaultValue="" required>
          <option value="" disabled>Elegí una opción</option>
          <option value="web">Desarrollo web</option>
          <option value="hosting">Hosting y dominios</option>
          <option value="correo">Correo corporativo</option>
          <option value="seo">SEO</option>
          <option value="ddns">DDNS y acceso remoto</option>
          <option value="red">Redes, servidores y monitoreo</option>
          <option value="impresion">Diseño e impresión 3D</option>
          <option value="otro">Otro</option>
        </select>
      </div>

      <div className="field-group">
        <label htmlFor="message">Mensaje</label>
        <textarea id="message" name="message" rows="6" placeholder="Contame qué necesitás, para cuándo y qué resultado esperás." required></textarea>
      </div>

      {feedback && (
        <p className={`contact-form-feedback ${feedback.type}`} role={feedback.type === 'error' ? 'alert' : 'status'}>
          {feedback.message}
        </p>
      )}
      <p className="contact-form-note">
        Al enviar, aceptás que use estos datos para responderte. Más información en la{' '}
        <Link to="/privacidad">política de privacidad</Link>.
      </p>
      <button type="submit" className="Btn_Send" disabled={submitting}>
        {submitting ? 'Enviando...' : 'Enviar consulta'}
      </button>
      {contact.phone && (
        <button type="button" className="secondary-button" onClick={handleWhatsApp}>
          Continuar por WhatsApp
        </button>
      )}
    </form>
  );
};

export default MailBox;
