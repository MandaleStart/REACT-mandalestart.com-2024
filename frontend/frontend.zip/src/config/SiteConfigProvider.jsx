import { useEffect, useState } from 'react';
import { fallbackContact, normalizeContactConfig } from './site';
import SiteConfigContext from './siteConfigContext';

const API_BASE_URL = (import.meta.env?.VITE_API_BASE_URL || '').replace(/\/$/, '');

function getInitialContact(initialConfig) {
  if (initialConfig) {
    try {
      return normalizeContactConfig(initialConfig);
    } catch {
      return fallbackContact;
    }
  }

  if (typeof document !== 'undefined') {
    try {
      const embeddedConfig = document.getElementById('site-config')?.textContent;
      if (embeddedConfig) return normalizeContactConfig(JSON.parse(embeddedConfig));
    } catch {
      return fallbackContact;
    }
  }

  return fallbackContact;
}

// The project uses JavaScript without runtime prop-type declarations.
// eslint-disable-next-line react/prop-types
export function SiteConfigProvider({ children, initialConfig }) {
  const [contact, setContact] = useState(() => getInitialContact(initialConfig));

  useEffect(() => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);

    fetch(`${API_BASE_URL}/api/site-config`, { signal: controller.signal })
      .then((response) => {
        if (!response.ok) throw new Error(`La API respondió con estado ${response.status}.`);
        return response.json();
      })
      .then((config) => setContact(normalizeContactConfig(config)))
      .catch((error) => {
        if (error.name !== 'AbortError') {
          console.warn('No se pudo actualizar la configuración pública de contacto:', error.message);
        }
      })
      .finally(() => clearTimeout(timeout));

    return () => {
      clearTimeout(timeout);
      controller.abort();
    };
  }, []);

  return <SiteConfigContext.Provider value={contact}>{children}</SiteConfigContext.Provider>;
}
