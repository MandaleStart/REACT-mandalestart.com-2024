###mandalestart.com - Página Web de Desarrollo Web
¡Bienvenido a mandalestart.com! Esta página web es tu destino para encontrar una amplia gama de servicios de desarrollo web, así como para conocer más sobre mí y explorar algunos de mis proyectos destacados.

#Servicios Principales
Diseño y Desarrollo de Sitios Web
En mandalestart.com, ofrecemos servicios completos de diseño y desarrollo de sitios web adaptados a tus necesidades específicas. Ya sea que necesites un sitio web informativo, una tienda en línea o una aplicación web personalizada, estamos aquí para hacer realidad tu visión.

#Optimización para Motores de Búsqueda (SEO)
Nos aseguramos de que tu sitio web sea fácilmente accesible y visible en los motores de búsqueda. Utilizamos técnicas de optimización para motores de búsqueda (SEO) para mejorar el ranking de tu sitio web y aumentar su visibilidad en línea.

#Diseño Responsivo
Todos nuestros sitios web están diseñados para ser totalmente responsivos, lo que garantiza una experiencia de usuario óptima en todos los dispositivos, desde ordenadores de escritorio hasta dispositivos móviles.

#Secciones Adicionales
Contacto
¿Listo para iniciar un proyecto o tienes alguna pregunta? ¡No dudes en ponerte en contacto con nosotros! Puedes encontrarnos en las siguientes plataformas:

Correo Electrónico: contact@mandalestart.com
Redes Sociales: Twitter, LinkedIn, Instagram
Galería de Proyectos
Echa un vistazo a nuestra galería de proyectos para ver algunos de nuestros trabajos anteriores. Aquí podrás encontrar una selección de sitios web que hemos desarrollado para nuestros clientes, junto con detalles sobre el alcance del proyecto y las tecnologías utilizadas.

#Acerca de Mí
Descubre más sobre el equipo detrás de mandalestart.com y nuestra pasión por el desarrollo web. En la sección "Acerca de Mí", compartimos nuestra historia, experiencia y valores fundamentales que guían nuestro trabajo.

#Tecnologías Utilizadas
Nuestros proyectos de desarrollo web hacen uso de una variedad de tecnologías modernas, que incluyen:

HTML5
CSS3 (con preprocesadores como Sass)
JavaScript (incluyendo frameworks como React)
Herramientas de Construcción como Webpack o Vite
Gestión de Versiones con Git
¿Listo para Empezar?
Si estás listo para llevar tu presencia en línea al siguiente nivel o si tienes alguna pregunta sobre nuestros servicios, ¡no dudes en ponerte en contacto con nosotros! Estamos emocionados de trabajar contigo en tu próximo proyecto web.

¡Gracias por visitar mandalestart.com!

## Compilación y SEO

`npm run build` genera una página HTML prerenderizada para cada ruta, con su contenido, encabezados y metadatos. También actualiza las URLs del sitemap y de `robots.txt`.

El dominio canónico predeterminado de este frontend es `https://dev.mandalestart.com`. Si se despliega en otro dominio, configurar `VITE_SITE_URL` en el entorno de compilación para que los canonical, las etiquetas sociales y el sitemap apunten al dominio correcto.

El área de clientes usa Firebase Authentication y consulta el backend en `/api/clients/me`. Configurá `VITE_API_BASE_URL` si la API está en otro host y `VITE_FIREBASE_*` con la configuración web de Firebase. Las credenciales de Firebase Admin deben configurarse únicamente en el servidor backend. En desarrollo, Vite reenvía `/api` a `http://localhost:4000` (cambiable con `VITE_API_PROXY_TARGET`).

Para compilar localmente con otro dominio desde PowerShell:

```powershell
$env:VITE_SITE_URL = "https://www.ejemplo.com"
npm run build
```